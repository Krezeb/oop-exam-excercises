﻿using System;

namespace GitCodeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            BookBuilder builder = new BookBuilder();
            Book book = builder.BuildBook();

            string format = "{0,-30} {1}";
            Console.WriteLine();
            Console.WriteLine(format, "Titel", "Författare");
            Console.WriteLine(format, book.Title, book.Author);
        }
    }
}
