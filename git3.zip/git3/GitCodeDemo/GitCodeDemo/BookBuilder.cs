﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GitCodeDemo
{
    class BookBuilder
    {
        public Book BuildBook()
        {
            Console.WriteLine("Enter a book title");
            string title = Console.ReadLine();
            Console.WriteLine("Enter an author name");
            string author = Console.ReadLine();
            Console.WriteLine("Enter a genre");
            string genre = Console.ReadLine();
            return new Book()
            {
                Title = title,
                Author = author,
                Genre = genre
            };
        }
    }
}
