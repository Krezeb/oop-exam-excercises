# Uppgift
Koden i GitCodeDemo hanteras av Git. Det finns redan fyra commits
på två olika branches. Din uppgift är att merge:a in feature-1 i
main-branchen. Efter merge:en ska programmet gå att köra och
funktionaliteten från båda branch:arna måste finns med.
