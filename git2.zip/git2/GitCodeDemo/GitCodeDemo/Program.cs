﻿using System;

namespace GitCodeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            SumHelper helper = new SumHelper();
            string result = helper.GetSum(1, 2);
            Console.WriteLine(result);
        }
    }
}
