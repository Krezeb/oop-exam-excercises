﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GitCodeDemo
{
    class SumHelper
    {
        public string GetSum(int value1, int value2)
        {
            int sum = value1 + value2;
            return $"The sum is: {sum}";
        }
    }
}
