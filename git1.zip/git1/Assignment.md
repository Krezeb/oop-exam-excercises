# Uppgift
I den här uppgiften finns redan ett Git-repo som har en commit. Din
uppgift är att göra git-operationerna som beskrivs nedan. Vi kommer
titta igenom git-historiken (git log) för att se om du följt
instruktionerna.

Filerna file1.md, file2.md och file3.md innehåller lite
slumpgenererat innehåll. Deras innehåll är inte viktigt för uppgiften

## A
Gör en commit med file1.md i. Meddelandet ska vara: "first commit".

## B
Skapa en branch som heter "tenta" och byt över till den. Gör en
commit med file2.md i. Meddelandet ska vara: "commit on tenta".

## C
Byt tillbaka till branchen "main" och gör en commit med file3.md i.
Meddelandet ska vara:

```
this is a commit
on multiple
lines
```

## D
Gör en merge av branchen "tenta" in i branchen "main". Använd
standardmeddelandet som Git skapar åt oss.
